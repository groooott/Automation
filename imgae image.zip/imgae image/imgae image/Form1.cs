﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imgae_image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public class ImageCapture
        {
            [DllImport("user32.dll")]
            public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint nFlags);

            [DllImport("user32.dll")]
            public static extern IntPtr GetForegroundWindow();

            public Bitmap CaptureActiveWindow()
            {
                // Get the active window handle
                IntPtr hwnd = GetForegroundWindow();

                // Get the dimensions of the window
                RECT windowRect = new RECT();
                GetWindowRect(hwnd, ref windowRect);

                int width = windowRect.Right - windowRect.Left;
                int height = windowRect.Bottom - windowRect.Top;

                // Create a bitmap with the same size as the window
                Bitmap bmp = new Bitmap(width, height);

                using (Graphics g = Graphics.FromImage(bmp))
                {
                    // Get the device context for the Graphics object
                    IntPtr hdc = g.GetHdc();
                    // Print the window content into the device context
                    PrintWindow(hwnd, hdc, 0);
                    // Release the device context
                    g.ReleaseHdc(hdc);
                }

                return bmp;  // Return the captured image
            }

            [StructLayout(LayoutKind.Sequential)]
            public struct RECT
            {
                public int Left;
                public int Top;
                public int Right;
                public int Bottom;
            }

            [DllImport("user32.dll")]
            public static extern bool GetWindowRect(IntPtr hWnd, ref RECT rect);
        }
    }
}
